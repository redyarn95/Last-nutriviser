module.exports = function(app, conn){
  var express = require('express');
  var router = express.Router();

  /* root */
  router.get('/', (req, res) => {
    res.redirect('/news');
  });
  router.get('/generic', (req, res) => {
    res.render('news/generic');
  });
  router.get('/form', (req, res) => {
    res.render('news/form');
  });
  router.get('/elements', (req, res) => {
    res.render('news/elements');
  });
  router.get('/landing-page', (req, res) => {
    res.render('news/landing-page');
  });
  router.get('/index', (req, res) => {
    res.render('news/index');
  });
  return router;
};
